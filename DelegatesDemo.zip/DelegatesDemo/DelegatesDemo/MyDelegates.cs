﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo
{
    internal class MyDelegates
    {
        public delegate bool SortDelegate<T>(T first, T second);
        public void MySort<T>(List<T> data, SortDelegate<T> sd)
        {
            for (int i = 0; i < data.Count(); i++)
            {
                for (int j = i + 1; j < data.Count(); j++)
                {
                    if (sd(data[i], data[j]))
                    {
                        T temp = data[i];
                         data[i] = data[j];
                        data[j] = temp;
                    }

                }
            }
        }

    }
}
