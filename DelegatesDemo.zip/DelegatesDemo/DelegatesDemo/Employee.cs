﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo
{
    internal class Employee 
    {
        public int Id { get; set; }
        public string Name {   get; set; }
        public string Dept { get; set; }
        public int Salary { get; set; }
        public  List<Employee> GetEmployees()
        {
            return new List<Employee>()
            {
                new Employee{Id=123,Name="Raj",Dept="TR",Salary=40000},
                new Employee{Id=103,Name="Tom",Dept="HR",Salary=70000},
                new Employee{Id=113,Name="Jay",Dept="TR",Salary=80000},
                new Employee{Id=193,Name="Ali",Dept="HR",Salary=60000},
                new Employee{Id=163,Name="Sam",Dept="TR",Salary=20000},
                new Employee{Id=183,Name="Bob",Dept="TR",Salary=30000},
            };
        }
    }
}
