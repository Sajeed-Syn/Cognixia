﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegatesDemo
{
    internal class Pen
    {
        public string Color { get; set; }
        public int Rate { get; set; }
        public List<Pen> GetPens()
        {
            return new List<Pen>()
            {
                new Pen { Rate = 300, Color = "Red" },
                new Pen { Rate = 100, Color = "Blue" },
                new Pen { Rate = 200, Color = "Black" },
                new Pen { Rate = 50, Color = "White" }
            };
        }
    }
}