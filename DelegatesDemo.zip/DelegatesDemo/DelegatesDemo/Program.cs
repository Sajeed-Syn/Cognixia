﻿namespace DelegatesDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Employee employee = new Employee();
            List<Employee> employees = employee.GetEmployees();
            MyDelegates md = new MyDelegates();
            MyDelegates.SortDelegate<Employee> sd = SortByName;
            // MyDelegates.SortDelegate<Employee> sd = SortBySalary;
            md.MySort<Employee>(employees, sd);
            foreach (var e in employees)
            {
                Console.WriteLine($"{e.Id} -- {e.Name} -- {e.Dept} -- {e.Salary}");
            }
            Console.WriteLine("++++++++++++++++++++++++++++");
            Pen pen = new Pen();
            List<Pen> pens = pen.GetPens();
            MyDelegates.SortDelegate<Pen> sd1 = SortByColor;
            md.MySort<Pen>(pens, sd1);
            foreach (var e in pens)
            {
                Console.WriteLine($"{e.Rate} --- {e.Color}");
            }
        }

        private static bool SortByColor(Pen first, Pen second)
        {
            return first.Color.CompareTo(second.Color) > 0;
        }

        private static bool SortBySalary(Employee first, Employee second)
        {
            return first.Salary > second.Salary;
        }

        private static bool SortByName(Employee first, Employee second)
        {
            return first.Name.CompareTo(second.Name) > 0;
        }
    }
}
