﻿using System.Runtime.CompilerServices;

namespace UnsafeCode
{
    internal class Program
    {
         unsafe static void Main(string[] args)
        {
            int[] num = { 10, 20, 30, 40, 50 };
            IncrementArray(num);
            for (int i = 0; i < num.Length; i++)
            {
                Console.WriteLine(num[i]);
            }

        }
        unsafe static void IncrementArray(int[] arr)
        {
            fixed (int* ptr = arr)
            {
                for (int i = 0; i < arr.Length; i++)
                {
                    ptr[i] += 1;
                }
            }
        }

        
       unsafe   static void Main(string[] args)
         {
             int value = 70;
             int* pointer = &value;

             Console.WriteLine($"Value: {*pointer}"); // Dereference
             *pointer = 100;
             Console.WriteLine($"New Value: {value}");
         } 
    }
}

