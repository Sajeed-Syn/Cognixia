﻿using System;
using System.Runtime.InteropServices;
using Excel = Microsoft.Office.Interop.Excel;

namespace ExcelInteropDemo
{
    class Program
    {
        static void Main()
        {
            Excel.Application excelApp = null;
            Excel.Workbooks workbooks = null;
            Excel.Workbook workbook = null;
            Excel.Worksheet worksheet = null;

            try
            {
                // Start Excel
                excelApp = new Excel.Application();
                excelApp.Visible = false;  // keep Excel hidden

                // Create a new workbook
                workbooks = excelApp.Workbooks;
                workbook = workbooks.Add();
                worksheet = (Excel.Worksheet)workbook.Sheets[1];

                // Write to cell
                worksheet.Cells[1, 1] = "Hello from C# to Excel!";
                worksheet.Cells[1, 2] = DateTime.Now.ToString();

                // Save the workbook
                string filePath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\SampleExcel.xlsx";
                workbook.SaveAs(filePath);

                Console.WriteLine("Excel file saved to: " + filePath);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: " + ex.Message);
            }
            finally
            {
                // Cleanup in reverse order
                if (workbook != null)
                {
                    workbook.Close(false);
                    Marshal.ReleaseComObject(workbook);
                }
                if (workbooks != null)
                    Marshal.ReleaseComObject(workbooks);
                if (worksheet != null)
                    Marshal.ReleaseComObject(worksheet);
                if (excelApp != null)
                {
                    excelApp.Quit();
                    Marshal.ReleaseComObject(excelApp);
                }

                // Force garbage collection
                GC.Collect();
                GC.WaitForPendingFinalizers();
            }

            Console.WriteLine("Done.");
        }
    }
}
