﻿using System;
using System.Threading;

class Program
{
    static void Main()
    {
        using Mutex mutex = new Mutex(false, "Global\\MyMutex");
        if (mutex.WaitOne(TimeSpan.FromSeconds(5)))
        {
            try
            {
                Console.WriteLine("Mutex acquired.");
                Thread.Sleep(2000); // Simulate work
            }
            finally
            {
                mutex.ReleaseMutex();
                Console.WriteLine("Mutex released.");
            }
        }
        else
        {
            Console.WriteLine("Could not acquire mutex.");
        }
    }
}
