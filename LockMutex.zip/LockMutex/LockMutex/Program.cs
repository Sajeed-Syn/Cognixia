﻿using System;
using System.Threading;

namespace SynchronizationPrimitivesDemo
{
    class Program
    {
        private static int _lockCounter = 0;
        private static int _mutexCounter = 0;
        private static int _semaphoreCounter = 0;

        private static object _lock = new object();
        private static Mutex _mutex = new Mutex();
        private static SemaphoreSlim _semaphore = new SemaphoreSlim(2); // allow 2 threads

        static void Main(string[] args)
        {
            Console.WriteLine("=== Using lock ===");
            for (int i = 0; i < 3; i++)
                new Thread(UseLock).Start();

            Thread.Sleep(1000); // Separation

            Console.WriteLine("\n=== Using Mutex ===");
            for (int i = 0; i < 3; i++)
                new Thread(UseMutex).Start();

            Thread.Sleep(1000); // Separation

            Console.WriteLine("\n=== Using Semaphore ===");
            for (int i = 0; i < 5; i++)
                new Thread(UseSemaphore).Start();

            Console.ReadLine();
        }

        static void UseLock()
        {
            lock (_lock)
            {
                Console.WriteLine($"[Lock] Thread {Thread.CurrentThread.ManagedThreadId} entering.");
                _lockCounter++;
                Thread.Sleep(500);
                Console.WriteLine($"[Lock] Thread {Thread.CurrentThread.ManagedThreadId} exiting. Count: {_lockCounter}");
            }
        }

        static void UseMutex()
        {
            _mutex.WaitOne();
            try
            {
                Console.WriteLine($"[Mutex] Thread {Thread.CurrentThread.ManagedThreadId} entering.");
                _mutexCounter++;
                Thread.Sleep(500);
                Console.WriteLine($"[Mutex] Thread {Thread.CurrentThread.ManagedThreadId} exiting. Count: {_mutexCounter}");
            }
            finally
            {
                _mutex.ReleaseMutex();
            }
        }

        static void UseSemaphore()
        {
            _semaphore.Wait();
            try
            {
                Console.WriteLine($"[Semaphore] Thread {Thread.CurrentThread.ManagedThreadId} entering.");
                _semaphoreCounter++;
                Thread.Sleep(1000);
                Console.WriteLine($"[Semaphore] Thread {Thread.CurrentThread.ManagedThreadId} exiting. Count: {_semaphoreCounter}");
            }
            finally
            {
                _semaphore.Release();
            }
        }
    }
}
