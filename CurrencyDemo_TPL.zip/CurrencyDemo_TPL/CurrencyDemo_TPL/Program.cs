﻿using System;
using System.Collections.Concurrent;
using System.Net.Http;
using System.Threading;
using System.Threading.Channels;
using System.Threading.Tasks;

class Program
{
    static async Task Main(string[] args)
    {
        Console.WriteLine("=== .NET Concurrency and Multithreading Demo ===\n");

        await CpuBoundParallel();
        await IoBoundWithThrottling();
        await ProducerConsumerChannel();
        SynchronizationDemo();
        CancellationDemo().Wait();
    }

    static async Task CpuBoundParallel()
    {
        Console.WriteLine("1) CPU-Bound Parallel Demo");

        var bag = new ConcurrentBag<long>();
        Parallel.ForEach(Enumerable.Range(0, 1000), new ParallelOptions { MaxDegreeOfParallelism = Environment.ProcessorCount }, i =>
        {
            long result = Fibonacci(20);
            bag.Add(result);
        });

        Console.WriteLine($"Total computed: {bag.Count}\n");
    }

    static long Fibonacci(int n) => n <= 1 ? n : Fibonacci(n - 1) + Fibonacci(n - 2);

    static async Task IoBoundWithThrottling()
    {
        Console.WriteLine("2) I/O-Bound Task with Throttling Demo");

        var urls = new[] {
            "https://www.example.com", "https://www.microsoft.com", "https://www.github.com"
        };
        using var http = new HttpClient();
        using var sem = new SemaphoreSlim(2); // Max 2 concurrent requests

        var tasks = urls.Select(async url =>
        {
            await sem.WaitAsync();
            try
            {
                var response = await http.GetAsync(url);
                var content = await response.Content.ReadAsStringAsync();
                Console.WriteLine($"{url} - {content.Length} chars");
            }
            finally
            {
                sem.Release();
            }
        });

        await Task.WhenAll(tasks);
        Console.WriteLine();
    }

    static async Task ProducerConsumerChannel()
    {
        Console.WriteLine("3) Producer-Consumer with Channel Demo");

        var channel = Channel.CreateBounded<int>(100);

        var producer = Task.Run(async () =>
        {
            for (int i = 0; i < 100; i++)
            {
                await channel.Writer.WriteAsync(i);
            }
            channel.Writer.Complete();
        });

        var consumer = Task.Run(async () =>
        {
            await foreach (var item in channel.Reader.ReadAllAsync())
            {
                if (item % 10 == 0)
                    Console.WriteLine($"Consumed: {item}");
            }
        });

        await Task.WhenAll(producer, consumer);
        Console.WriteLine();
    }

    static void SynchronizationDemo()
    {
        Console.WriteLine("4) Synchronization with Interlocked");

        int counter = 0;
        Parallel.For(0, 10000, _ =>
        {
            Interlocked.Increment(ref counter);
        });

        Console.WriteLine($"Final counter value: {counter}\n");
    }

    static async Task CancellationDemo()
    {
        Console.WriteLine("5) CancellationToken Demo");

        using var cts = new CancellationTokenSource(2000); // 2 seconds
        try
        {
            await Task.Delay(5000, cts.Token); // Simulate long work
        }
        catch (OperationCanceledException)
        {
            Console.WriteLine("Task was cancelled due to timeout.");
        }

        Console.WriteLine();
    }
}
