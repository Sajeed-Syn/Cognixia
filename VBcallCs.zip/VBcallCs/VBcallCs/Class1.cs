﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VBcallCs
{
    public class MyMaths
    {
        public int add(int x, int y)
        {
            return x + y;
        }
    }
}
