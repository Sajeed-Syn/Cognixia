﻿using System;
using System.Runtime.InteropServices;
using VB6Hello;
namespace CallVB6
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            Greet greetings = new Greet();
            Console.WriteLine($"{greetings.SayHello("Tom")}");
            Marshal.ReleaseComObject(greetings);
        }
    }
}
