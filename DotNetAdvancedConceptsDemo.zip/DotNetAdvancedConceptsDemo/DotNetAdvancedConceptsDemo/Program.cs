
using System;
using System.Threading;
using System.Threading.Tasks;

namespace DotNetAdvancedConceptsDemo
{
    class Program
    {
        static async Task Main(string[] args)
        {
            Console.WriteLine("Starting Demo...");

            // Thread Demo
            ThreadDemo.Run();

            // ThreadPool Demo
            ThreadPoolDemo.Run();

            // Async Await Demo
            await AsyncAwaitDemo.RunAsync();

            // Task Parallel Library Demo
            TPLDemo.Run();

            // Unsafe Code Demo
            UnsafeCodeDemo.Run();

            // Synchronization Demo
            SynchronizationDemo.Run();

            Console.WriteLine("All demos completed.");
        }
    }
}
