
using System;
using System.Threading.Tasks;

namespace DotNetAdvancedConceptsDemo
{
    public static class TPLDemo
    {
        public static void Run()
        {
            Parallel.For(0, 3, i =>
            {
                Console.WriteLine($"TPL running task {i} on Thread ID: {Thread.CurrentThread.ManagedThreadId}");
            });
        }
    }
}
