
using System;
using System.Threading;

namespace DotNetAdvancedConceptsDemo
{
    public static class ThreadPoolDemo
    {
        public static void Run()
        {
            ThreadPool.QueueUserWorkItem(_ =>
            {
                Console.WriteLine($"ThreadPool running on ID: {Thread.CurrentThread.ManagedThreadId}");
                Thread.Sleep(500);
            });

            Thread.Sleep(1000);
        }
    }
}
