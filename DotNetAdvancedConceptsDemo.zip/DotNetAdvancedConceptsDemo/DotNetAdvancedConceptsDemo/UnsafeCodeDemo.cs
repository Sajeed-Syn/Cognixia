
using System;

namespace DotNetAdvancedConceptsDemo
{
    public static class UnsafeCodeDemo
    {
        public static unsafe void Run()
        {
            int val = 10;
            int* ptr = &val;
            Console.WriteLine($"Unsafe - Address: {(ulong)ptr}, Value: {*ptr}");
            *ptr = 99;
            Console.WriteLine($"Unsafe - New Value: {val}");
        }
    }
}
