
using System;
using System.Threading;

namespace DotNetAdvancedConceptsDemo
{
    public static class ThreadDemo
    {
        public static void Run()
        {
            Thread t = new Thread(() =>
            {
                Console.WriteLine($"Thread running on ID: {Thread.CurrentThread.ManagedThreadId}");
                Thread.Sleep(500);
            });
            t.Start();
            t.Join();
        }
    }
}
