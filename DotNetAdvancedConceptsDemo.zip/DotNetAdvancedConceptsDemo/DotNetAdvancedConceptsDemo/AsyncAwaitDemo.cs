
using System;
using System.Net.Http;
using System.Threading.Tasks;

namespace DotNetAdvancedConceptsDemo
{
    public static class AsyncAwaitDemo
    {
        public static async Task RunAsync()
        {
            using HttpClient client = new();
            string content = await client.GetStringAsync("https://www.example.com");
            Console.WriteLine($"Downloaded {content.Length} characters");
        }
    }
}
