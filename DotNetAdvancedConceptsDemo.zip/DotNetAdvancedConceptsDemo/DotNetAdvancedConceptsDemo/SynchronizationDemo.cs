
using System;
using System.Threading;

namespace DotNetAdvancedConceptsDemo
{
    public static class SynchronizationDemo
    {
        private static readonly object _lock = new();
        private static Semaphore _semaphore = new(1, 1);
        private static Mutex _mutex = new();

        public static void Run()
        {
            lock (_lock)
            {
                Console.WriteLine("Lock acquired.");
            }

            _mutex.WaitOne();
            Console.WriteLine("Mutex acquired.");
            _mutex.ReleaseMutex();

            _semaphore.WaitOne();
            Console.WriteLine("Semaphore acquired.");
            _semaphore.Release();
        }
    }
}
