﻿using System;
using System.Threading;

class Program
{
    static SemaphoreSlim semaphore = new SemaphoreSlim(3); // allow 3 threads at a time

    static void AccessResource(int threadNumber)
    {
        Console.WriteLine($"Thread {threadNumber} waiting...");
        semaphore.Wait();
        try
        {
            Console.WriteLine($"Thread {threadNumber} acquired semaphore.");
            Thread.Sleep(1000);
        }
        finally
        {
            Console.WriteLine($"Thread {threadNumber} released semaphore.");
            semaphore.Release();
        }
    }

    static void Main()
    {
        for (int i = 1; i <= 5; i++)
        {
            int local = i;
            new Thread(() => AccessResource(local)).Start();
        }
    }
}
