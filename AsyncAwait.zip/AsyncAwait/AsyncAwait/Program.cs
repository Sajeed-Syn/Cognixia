﻿using System;
using System.Net.Http;
using System.Threading.Tasks;

class Program
{
    static async Task Main()
    {
        string content = await DownloadWebPageAsync("https://example.com");
        Console.WriteLine(content.Substring(0, 500));
    }

    static async Task<string> DownloadWebPageAsync(string url)
    {
        using var client = new HttpClient();
        return await client.GetStringAsync(url);
    }
}
