﻿using System;
using System.Runtime.InteropServices;

class Program
{
    


     [DllImport("user32.dll", CharSet = CharSet.Unicode)]
     public static extern int MessageBox(IntPtr hWnd, string text, string caption, uint type);

     static void Main()
     {
        Type type = typeof(Pen);



         MessageBox(IntPtr.Zero, "Hello from C#!", "P/Invoke Demo", 0);
     }
    
   /* [DllImport("kernel32.dll")]
    public static extern bool Beep(int frequency, int duration);

    static void Main()
    {
        Beep(750, 300); // 750 Hz for 300 ms
    }
   */
}
