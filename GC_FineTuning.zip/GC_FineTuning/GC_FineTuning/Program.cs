﻿class Program
{
    static void Main()
    {
        Console.WriteLine("=== .NET Garbage Collection Demo ===");
        Console.WriteLine($"\n[Before allocation] Total Memory: {GC.GetTotalMemory(false)} bytes");
        // Allocate large number of objects
        object[] objects = new object[100000];
        for (int i = 0; i < objects.Length; i++)
        {
            objects[i] = new byte[1024]; // Allocate 1 KB
        }
        Console.WriteLine($"\n[After allocation] Total Memory: {GC.GetTotalMemory(false)} bytes");
        // Check generation of a sample object
        Console.WriteLine($"Sample object is in Generation: {GC.GetGeneration(objects[0])}");
        // Nullify references
        for (int i = 0; i < objects.Length; i++)
        {
            objects[i] = null;
        }
        // Force garbage collection 
        GC.Collect();
        GC.WaitForPendingFinalizers();
        GC.Collect();
        Console.WriteLine($"\n[After GC] Total Memory: {GC.GetTotalMemory(true)} bytes");
        Console.WriteLine("\nGarbage Collection Complete.");
        // Print GC collection count for each generation
        for (int i = 0; i <= GC.MaxGeneration; i++)
        {
            Console.WriteLine($"Gen {i} collection count: {GC.CollectionCount(i)}");
        }
    }
}
