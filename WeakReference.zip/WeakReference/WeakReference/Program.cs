﻿class Sample
{
    public string Data = "Important Info";
}

class Program
{
    static void Main()
    {
        var sample = new Sample();
        var weakRef = new WeakReference<Sample>(sample);
        // Remove strong reference
        sample = null;
        // Try to retrieve the object
       // var x=sample.Data;
        if (weakRef.TryGetTarget(out Sample retrieved))
        {
            Console.WriteLine(retrieved.Data);
        }
        else
        {
            Console.WriteLine("Object has been collected.");
        }
    }
}
